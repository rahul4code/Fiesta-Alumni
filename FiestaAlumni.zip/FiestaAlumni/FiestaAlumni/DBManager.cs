﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace FiestaAlumni
{
    public class DBManager
    {
        SqlConnection con=new SqlConnection("Data Source=HOGWARDS-PC;Initial Catalog=FiestaAlumni;Integrated Security=True");
         public bool insertupdatedelete(string command)
        {
            SqlCommand cmd = new SqlCommand(command,con);
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            int j = cmd.ExecuteNonQuery();
            if (j > 0)
                return true;
            else
                return false;
        }
        public DataTable readbulkdata(string command)
        {
            SqlDataAdapter sa = new SqlDataAdapter(command,con);
            DataTable dt = new DataTable();
            sa.Fill(dt);
            return dt;
        }

    }
}

 