﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.Data.SqlClient;

namespace FiestaAlumni.Controllers
{
    public class HomeController : Controller
    {
        //
        DBManager dbm = new DBManager();
        // GET: /Home/

        public ActionResult Index()
        {
               
        return View();

        }

        public void Redirect()
        {
            Response.Redirect("/Views/Home/Home.cshtml");
        }

        public ActionResult Home()
        {
            return View();
        }
        public ActionResult Event()
        {
            return View();
        }
        public ActionResult Gallary() 
        {
            return View();
        }
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(string username,string password)
        {
            string q = "Select * from Registration where email='" + username + "' and password='" + password + "'";
            DataTable dt = new DataTable();
            dt = dbm.readbulkdata(q);
            if (dt.Rows.Count > 0)
            {
                Response.Redirect("/Home/User");
            }
            else 
            {
                Response.Write("<script>alert('Invalid username or Password ')</script>");
            }

            return View();
        }

        public ActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Register(string AffiliationSelect, string year,
            string dept, string fname,string lname, string email,string pass)
        {
            if (year == "") {
                year = "default";
            
            }
            
            string q = "insert into Registration values ('" + AffiliationSelect + "'," + year + ",'" + dept + "','" + fname + "','"+lname+"','"+email+"','"+pass+"')";

            bool j = dbm.insertupdatedelete(q);

            if (j == true)
                Response.Write("<script>alert('Registration Successful')</script>");
            else
                Response.Write("<script>alert('Registration failed')</script>");
                
            return View();
        }

        public ActionResult User()
        {
            return View();
        }
        public ActionResult Message()
        {
            return View();
        }
        public ActionResult ChangePassword()
        {
            return View();
        }
        public ActionResult AdminPanel()
        {
            return View();
        }
        public ActionResult Searching()
        {
            return View();
        }
        public ActionResult AboutUs()
        {
            return View();
        }
        public ActionResult Group()
        {
            return View();
        }
        public ActionResult AdminLogin()
        {
            return View();
        }
        public ActionResult UserEvent()
        {
            return View();
        }
        public ActionResult UserGallery()
        {
            return View();
        }
        public ActionResult AdminEvent()
        {
            return View();
        }
        public ActionResult UploadGallery() 
        {
            return View();
        }
        public ActionResult AdminChangePass()
        {
            return View();
        }
        public ActionResult ForgotPass()
        {
            return View();
        }
    }
}
